import singleton
import strategy
import image
import facade
import recognition
