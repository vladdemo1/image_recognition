"""
This module contains simple function for test
"""

def simple_function() -> None:
    """
    Simple func
    """
    print("-- ПерСиК 2023 --")
    return None


simple_function()
